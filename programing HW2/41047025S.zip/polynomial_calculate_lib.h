#pragma once

#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <iomanip>
#include <cmath>
#include <string.h>
#include "polynomial.h"
using namespace std;

void print_line();
void wait();
void hello();
int64_t find_polynomial(const string say);
bool check_same_name(string name);

